import 'package:flutter/material.dart';

void main() => runApp(const AlamedaApp());

class AlamedaApp extends StatelessWidget {
  const AlamedaApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF173B25);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Exército de Alameda',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: green,
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF08130D),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF102719),
          foregroundColor: Colors.white,
        ),
      ),
      home: const DashboardPage(),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('EXÉRCITO DE ALAMEDA',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_outlined),
          )
        ],
      ),
      drawer: const AlamedaDrawer(),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Painel inicial',
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 6),
          const Text('Visão geral da administração do setor.'),
          const SizedBox(height: 18),
          const Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              MetricCard('Total de efetivos', '—', Icons.groups),
              MetricCard('Ativos', '—', Icons.verified_user),
              MetricCard('Pendentes', '—', Icons.hourglass_top),
              MetricCard('Eventos', '—', Icons.event),
            ],
          ),
          const SizedBox(height: 18),
          const InfoTile(Icons.leaderboard, 'Ranking semanal',
              'Classificação carregada após integração com o banco.'),
          const InfoTile(Icons.campaign, 'Comunicados',
              'Avisos oficiais do comando.'),
          const InfoTile(Icons.assignment, 'Atividades e presença',
              'Registros e acompanhamento dos efetivos.'),
          const SizedBox(height: 12),
          const Text(
            'Interface inicial: os dados ainda não estão conectados ao Supabase.',
            style: TextStyle(color: Colors.white60, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class MetricCard extends StatelessWidget {
  const MetricCard(this.label, this.value, this.icon, {super.key});
  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 155,
        child: Card(
          color: const Color(0xFF11251A),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: const Color(0xFFD6B45A), size: 26),
                const SizedBox(height: 10),
                Text(label, style: const TextStyle(color: Colors.white70)),
                Text(value,
                    style: const TextStyle(
                        fontSize: 26, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      );
}

class InfoTile extends StatelessWidget {
  const InfoTile(this.icon, this.title, this.subtitle, {super.key});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Card(
        color: const Color(0xFF11251A),
        child: ListTile(
          leading: Icon(icon, color: const Color(0xFFD6B45A)),
          title: Text(title),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {},
        ),
      );
}

class AlamedaDrawer extends StatelessWidget {
  const AlamedaDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    const entries = <(String, IconData)>[
      ('Início', Icons.home),
      ('Meu perfil', Icons.person),
      ('Efetivos', Icons.groups),
      ('Presença', Icons.fact_check),
      ('Atividades', Icons.assignment),
      ('Eventos', Icons.event),
      ('Ranking', Icons.leaderboard),
      ('Relatórios', Icons.insert_chart),
      ('Comunicados', Icons.campaign),
      ('Biblioteca', Icons.library_books),
      ('Administração', Icons.admin_panel_settings),
    ];
    return Drawer(
      backgroundColor: const Color(0xFF102719),
      child: SafeArea(
        child: ListView(
          children: [
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('EXÉRCITO\nDE ALAMEDA',
                  style: TextStyle(
                      color: Color(0xFFD6B45A),
                      fontSize: 22,
                      fontWeight: FontWeight.bold)),
            ),
            for (final entry in entries)
              ListTile(
                leading: Icon(entry.$2, color: const Color(0xFFD6B45A)),
                title: Text(entry.$1),
                onTap: () => Navigator.pop(context),
              ),
          ],
        ),
      ),
    );
  }
}
